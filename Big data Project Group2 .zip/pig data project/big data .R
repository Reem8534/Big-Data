
# Load required libraries
install.packages('tidyverse')
install.packages('tidytext')
install.packages('topicmodels')
install.packages('SnowballC')
install.packages('tm', dependencies = TRUE)
install.packages('NLP')
install.packages('e1071')

install.packages("reshape2")
# Install the stringdist package if not already installed
install.packages("wordcloud")
install.packages("stringdist")
library(e1071)
library(stringdist)
update.packages(ask=FALSE)
# read in the libraries we're going to use
library(tidyverse) # general utility & workflow functions
library(tidytext) # tidy implimentation of NLP methods
library(topicmodels) # for LDA topic modelling 
library(tm) # general text mining functions, making document term matrixes
library(SnowballC) # for stemming
library(stringr)
library(dplyr)
library(ggplot2)
library(wordcloud)
library(dplyr)

# Load required libraries
library(tidyr)
library(arules)
library(arulesViz)












#2.1 dataset description 
#import the dataset to a variable named dataset
dataset <-read.csv("C:/Users/xmiss/Downloads/archive (6)/DataAnalyst.csv") 
#check size of dataset
dim(dataset) 
#check number of attributes (columns)
ncol(dataset)
#check the type of each attribute
str(dataset)
#sample of dataset
summary(dataset)
#first six rows
head(dataset)

#Find number of distinct Job.Job.Title
length(unique(dataset$Job.Title))
# Find the most frequent value in the 'job title'
names(sort(table(dataset$Job.Title), decreasing = TRUE))[1:10]
#Find number of distinct company
length(unique(dataset$Company.Name))
# Find the most frequent value in the 'company'
names(sort(table(dataset$Company.Name), decreasing = TRUE))[1:10]
#Find number of distinct Location
length(unique(dataset$Location))
# Find the most frequent value in the 'Location'
names(sort(table(dataset$Location), decreasing = TRUE))[1:10]
#Find number of distinct indestury
length(unique(dataset$Industry))
# Find the most frequent value in the 'Industry'
names(sort(table(dataset$Industry), decreasing = TRUE))[1:10]
#Find number of distinct Sector
length(unique(dataset$Sector))
# Find the most frequent value in the 'Sector'
names(sort(table(dataset$Sector), decreasing = TRUE))[1:10]

#look for null value but we have -1 value which represent null
any(is.na(dataset))
#if there is any null value delete it
dataset<-na.exclude(dataset)
# Removing -1 from rating and salary estimate
dataset <- dataset[dataset$Rating != -1 & dataset$Salary.Estimate != -1 &dataset$Founded != -1 ,]
#check size of dataset after delete (will be the same)
dim(dataset) 
#look for duplication
any(duplicated(dataset))
#clear est salary(Glassdoor est.)
dataset$Salary.Estimate <- sub("\\(Glassdoor est.\\)", "", dataset$Salary.Estimate )
# Separating salary.estimate into min_salary and max_salary
dataset <- dataset %>%
  separate(Salary.Estimate, into = c("min.salary", "max.salary"), sep = "-")
# Extracting numbers only
dataset$min.salary <- parse_number(dataset$min.salary)
dataset$max.salary <- parse_number(dataset$max.salary)
# Extracting last two characters of location to get State Code
dataset <- dataset %>%
  mutate(Location = substr(Location, start = nchar(Location) - 1, stop = nchar(Location)))
# Multiplying min_salary and max_salary by 1000
dataset$min.salary <- dataset$min.salary * 1000
dataset$max.salary <- dataset$max.salary * 1000

# Creating Average Salary column
dataset$average.salary = (dataset$min.salary + dataset$max.salary)/2















#2.2 study destribution

# Summary of the 18 attribute: 
summary(dataset$X) 
summary(dataset$Job.Title) 
summary(dataset$average.salary) 
summary(dataset$Job.Description) 
summary(dataset$Rating) 
summary(dataset$Company.Name)
summary(dataset$Location) 
summary(dataset$Headquarters) 
summary(dataset$Size) 
summary(dataset$Founded) 
summary(dataset$Industry) 
summary(dataset$Type.of.ownership) 
summary(dataset$Sector) 
summary(dataset$Revenue) 
summary(dataset$Competitors) 
summary(dataset$Easy.Apply) 
summary(dataset$min.salary) 
summary(dataset$max.salary) 
# Histogram: 
hist(dataset$Rating)
hist(dataset$Founded)
# Distribution plot: 
plot(density(dataset$min.salary)) 
plot(density(dataset$max.salary)) 
#relation between salary and rating
plot(dataset$Rating,dataset$average.salary)


#1) Plot histogram for for the most frequent Data Science Job Titles
dataset %>%
  count(Job.Title, sort = TRUE) %>%
  head(10) %>%
  ggplot(aes(x = reorder(Job.Title, -n), y = n, fill = Job.Title)) +
  geom_col() +
  labs(x = 'Job Title', y = 'Count', title = 'Top 10 Data Science Job Titles') +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


#2) Plot histogram for the most frequent company
dataset %>%
  count(Company.Name, sort = TRUE) %>%
  head(10) %>%
  ggplot(aes(x = reorder(Company.Name, -n), y = n, fill = Company.Name)) +
  geom_col() +
  labs(x = 'Company.Names', y = 'Count', title = 'Top 10 Data Science company') +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#3) Plot histogram for for the most frequent Industry
dataset %>%
  count(Industry, sort = TRUE) %>%
  head(10) %>%
  ggplot(aes(x = reorder(Industry, -n), y = n, fill = Industry)) +
  geom_col() +
  labs(x = 'Industry', y = 'Count', title = 'Top 10 Industry') +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#4) Plot histogram for the most freq Sector
dataset %>%
  count(Sector, sort = TRUE) %>%
  head(10) %>%
  ggplot(aes(x = reorder(Sector, -n), y = n, fill = Sector)) +
  geom_col() +
  labs(x = 'Sector', y = 'Count', title = 'Top 10 Sector') +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#5) Plot histogram for the most freq Locations
dataset %>%
  count(Location, sort = TRUE) %>%
  head(10) %>%
  ggplot(aes(x = reorder(Location, -n), y = n, fill = Location)) +
  geom_col() +
  labs(x = 'Location', y = 'Count', title = 'Top 10 Locations') +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))





# List of skills to match
tools <- c("Python","R","SQL","Jupyter","NumPy","Pandas","Matplotlib","Seaborn",
           "SciPy","Scikit-Learn","TensorFlow","PyTorch","Keras","XGBoost","LightGBM",
           "Plotly","Dask","Spark","Hadoop","AWS","Google Cloud",
           "Azure","IBM Watson","NLTK","OpenCV","Gensim","StatsModels",
           "Theano","Caffe","Keras-Tuner","Auto-Keras","Auto-Sklearn","Shap","ELI5","Bokeh",
           "Folium","ggplot","plotnine","Geopandas","Datashader","Yellowbrick","H2O.ai","Flask",
           "Dash","Streamlit","FastAPI","PySpark","TensorBoard","cuDF","NetworkX","BeautifulSoup",
           "Scrapy","Numba","Cython", "Apache", "Git", "Excel")

# Perform phrase matching and store the result in 'Tools' column
dataset$Tools <- sapply(dataset$Job.Description, function(x) {
  matched_phrases <- str_extract_all(x, paste(tools, collapse = "|"))
  return(unique(unlist(matched_phrases)))
})

head(dataset)

generate_countplot(dataset, "Tools", 20)


#remove any symbol in Tools
dataset$Tools <- sub("^c\\(", "", dataset$Tools )
dataset$Tools <- gsub('"', '', dataset$Tools)
dataset$Tools <- sub(")", '', dataset$Tools )
# Separate the comma-separated values into different rows
dataset <- separate_rows(dataset, Tools, sep = ",")
# Perform one-hot encoding
dataset<- spread(dataset, Tools, Tools, fill = 0)  
#show changes in dataset
str(dataset)

#create dataframe for only Tools
dt<- subset(dataset, select = -c(X,Job.Title,Job.Description,Company.Name,Rating 
                                 ,Headquarters,Size,Founded,Location,Industry,
                                 Type.of.ownership,Sector,Revenue,Competitors
                                 ,Easy.Apply,min.salary,max.salary,average.salary))
#convert any string to 0 or 1
dt[] <- lapply(dt, function(x) ifelse(x != 0, 1, x))
# Check if there are any non-numeric or non-logical elements in the data frame
any(!sapply(dt, is.numeric) & !sapply(dt, is.logical))
# Convert non-numeric columns to numeric if necessary
dt[] <- lapply(dt, as.numeric)
#convert to matrix 
dt<-as.matrix(dt)
# Convert the 'Tools' columns to a transaction format
dt <- as(dt, "transactions")

























#hypothisess testing
#Null Hypothesis: no relation between the Salary based on rating provided. 
#Alternative Hypothesis: a relation between the Salary based on rating provided. 
#We want to reject the null hypothesis and accept the alternative hypothesis.
chisq_result <- chisq.test(dt)
# reject the null hypothesis and accept the alternative hypothesis(p=0.006171)
print(chisq_result)
#model planing 
# Assuming rules_pred contains your association rules
# Extracting confidence values for testing
conf_values <- quality(dt)$confidence

# Perform a chi-squared test on confidence values
chi_squared_test <- chisq.test(conf_values)


#2.3 data cleaning

#cleaning text 
# create a corpus (type of object expected by tm and document term matrix)
Corpus <- Corpus(VectorSource(dataset$Job.Description)) 
#turn all char to lower case 
Corpus<-tm_map(Corpus, content_transformer(tolower))
#remove punctuation marks
Corpus<-tm_map(Corpus, removePunctuation)
#remove numbers
Corpus<-tm_map(Corpus,removeNumbers )
# Remove stop words
Corpus <- tm_map(Corpus, content_transformer(function(x) removeWords(x, stopwords("en"))))
#Remove this •
Corpus <- gsub("[[:punct:]]", "", Corpus)

# get the count of words/document
DTM <- DocumentTermMatrix(Corpus) 
# Convert the document-term matrix to a data frame
dtm_df <- as.data.frame(as.matrix(DTM))
# Print the Bag of Words data frame
print(dtm_df)
# get the index of each unique value
unique_indexes <- unique(DTM$i)
# get a subset of only those indexes
DTM <- DTM[unique_indexes,] 

# preform LDA & get the words/topic in a tidy text format
lda <- LDA(DTM, k = 6, control = list(seed = 1234)) #this take time
topics <- tidy(lda, matrix = "beta")
# get the top ten terms for each topic
top_terms <- topics  %>% # take the topics data frame 
  group_by(topic) %>% # treat each topic as a different group
  top_n(10, beta) %>% # get the top 10 most informative words
  ungroup() %>% # ungroup
  arrange(topic, -beta) # arrange words in descending informativeness
# plot the top ten terms for each topic in order
top_terms %>% # take the top terms
  mutate(term = reorder(term, beta)) %>% # sort terms by beta value 
  ggplot(aes(term, beta, fill = factor(topic))) + # plot beta by theme
  geom_col(show.legend = FALSE) + # as a bar plot
  facet_wrap(~ topic, scales = "free") + # which each topic in a seperate plot
  labs(x = NULL, y = "Beta") + # no x label, change y label 
  coord_flip() # turn bars sideways
# return a list of sorted terms instead
print(top_terms)

#wordcloud 
wordcloud(Corpus, max.words = 100, random.order = FALSE)
















#Model Building

#Apriori
# Load required libraries
library(tidyr)
library(arules)
library(arulesViz)

#remove any symbol in Tools
dataset$Tools <- sub("^c\\(", "", dataset$Tools )
dataset$Tools <- gsub('"', '', dataset$Tools)
dataset$Tools <- sub(")", '', dataset$Tools )
# Separate the comma-separated values into different rows
dataset <- separate_rows(dataset, Tools, sep = ",")
# Perform one-hot encoding
dataset<- spread(dataset, Tools, Tools, fill = 0)  
#show changes in dataset
str(dataset)

#create dataframe for only Tools
dt<- subset(dataset, select = -c(X,Job.Title,Job.Description,Company.Name,Rating 
                                 ,Headquarters,Size,Founded,Location,Industry,
                                 Type.of.ownership,Sector,Revenue,Competitors
                                 ,Easy.Apply,min.salary,max.salary,average.salary))
#convert any string to 0 or 1
dt[] <- lapply(dt, function(x) ifelse(x != 0, 1, x))
# Check if there are any non-numeric or non-logical elements in the data frame
any(!sapply(dt, is.numeric) & !sapply(dt, is.logical))
# Convert non-numeric columns to numeric if necessary
dt[] <- lapply(dt, as.numeric)
#convert to matrix 
dt<-as.matrix(dt)
# Convert the 'Tools' columns to a transaction format
dt <- as(dt, "transactions")

# frequent 1-itemsets
itemsets <- apriori(dt, parameter=list(minlen=1, maxlen=1, support=0.02, target="frequent itemsets"))
summary(itemsets)
inspect(head(sort(itemsets, by = "support"), 10))
# frequent 2-itemsets
itemsets <- apriori(dt, parameter=list(minlen=2, maxlen=2, support=0.02, target="frequent itemsets"))
summary(itemsets)
inspect(head(sort(itemsets, by ="support"),10))
# frequent 3-itemsets
itemsets <- apriori(dt, parameter=list(minlen=3, maxlen=3, support=0.02, target="frequent itemsets"))
summary(itemsets)
inspect(head(sort(itemsets, by ="support"),10))
# frequent 4-itemsets
itemsets <- apriori(dt, parameter=list(minlen=4, maxlen=4, support=0.02, target="frequent itemsets"))
summary(itemsets)
inspect(head(sort(itemsets, by ="support"),10))

#Build model 
set.seed(123)
#split data to train and test 
split <- sample(1:nrow(dt), 0.8 * nrow(dt))
train_data <- dt[split, ]
test_data <- dt[-split, ]
#train
rules_train <- apriori(train_data, parameter = list(supp = 0.02, conf = 0.5))
# Subset the rules to only include those relevant to the testing data
rules_pred <- subset(rules_train, test_data)
# Extract the rule quality measures
quality(rules_pred)
summary(rules_pred)
# Visualize the rules and their quality measures
plot(rules_pred, method = "scatterplot")
# Get the top rules based on lift
top_rules <- head(sort(rules_train, by = "lift"), 10)
inspect(top_rules)


